/** Automatically generated file. DO NOT MODIFY */
package com.honestwalker.androidutils;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}