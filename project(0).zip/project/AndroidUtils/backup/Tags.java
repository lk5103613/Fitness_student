package com.honestwalker.androidutils.IO;

public enum Tags {
	CHECK_IN, 
	REQUEST, 
	WELCOME, 
	DBLoginuser,
	HOTEL,
	FIRST_RUNNED, 
	OperatingData, LOGIN, HomeinnsApplication, LoadingHelper, REQUEST2,
	ActivityRun, DateSelector,
	MotionEvent,
	SendPwd, InputMethod, 
	TitleClick,
	MessageClick,
	MessageFlag, MessageActivity,
	HOMETOUCH
}
