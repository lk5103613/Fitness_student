package com.honestwalker.androidutils;

import android.app.Activity;

public class MyActivity extends Activity{
	
}
