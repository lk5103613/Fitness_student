package com.honestwalker.androidutils;

public class AndroidUtilsContext {
	public static String desKey;

	public static String getDesKey() {
		return desKey;
	}

	public static void setDesKey(String desKey) {
		AndroidUtilsContext.desKey = desKey;
	}
	
}
