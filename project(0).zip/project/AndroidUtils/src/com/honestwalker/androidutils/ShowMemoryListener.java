package com.honestwalker.androidutils;

public interface ShowMemoryListener {
	public void onShow(double heapsize,double total);
}
