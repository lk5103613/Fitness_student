package com.honestwalker.androidutils.activity.fragment.menubar;

public class MenubarItemBean {
	private int iconResId;
	private String text;
	private String fragmentClass;
	private int labelColorResId;
	
	public int getIconResId() {
		return iconResId;
	}
	public void setIconResId(int iconResId) {
		this.iconResId = iconResId;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getFragmentClass() {
		return fragmentClass;
	}
	public void setFragmentClass(String fragmentClass) {
		this.fragmentClass = fragmentClass;
	}
	public void setLabelColorResId(int labelColorResId) {
		this.labelColorResId = labelColorResId;
	}
	public int getLabelColorResId() {
		return labelColorResId;
	}
}
