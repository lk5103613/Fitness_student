package com.honestwalker.androidutils.activity.menubar;

/**
 * 菜单初始化异常
 * @author honestwalker
 *
 */
public class MenubarInitException extends Exception {
	public MenubarInitException(String message) {
		super(message);
	}
}
