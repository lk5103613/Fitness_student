package com.honestwalker.androidutils.activity.fragment.menubar;

public interface OnMenubarChangeListener {
	
	public void onChange(int index);
	
	public void onChanged(int index);
	
}
